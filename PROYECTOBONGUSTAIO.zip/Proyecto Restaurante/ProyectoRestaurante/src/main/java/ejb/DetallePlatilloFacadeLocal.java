/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import entity.DetallePlatillo;
import java.util.List;
import javax.ejb.Local;

@Local
public interface DetallePlatilloFacadeLocal {
    
 void create (DetallePlatillo detallePlatillo);
    
    List<DetallePlatillo> findAll();
    
    void delete(DetallePlatillo detallePlatillo);
    
    void edit(DetallePlatillo detallePlatillo);
    
    DetallePlatillo find(Object id);
}