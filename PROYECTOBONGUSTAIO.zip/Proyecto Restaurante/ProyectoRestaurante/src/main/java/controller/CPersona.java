/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import ejb.PersonaFacadeLocal;
import entity.Cargo;
import entity.Persona;
import entity.Sucursal;
import java.io.Serializable;
import static java.lang.Integer.getInteger;
import java.util.List;
import java.util.Locale;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Named;

@Named(value = "cPersona")
@SessionScoped
public class CPersona implements Serializable {

    @EJB
    private PersonaFacadeLocal perEJB;
    private Persona per;
    private List<Persona> lista;
    private List<Persona> filter;
    private Cargo car;
    private Sucursal suc;
    String mensa = "";

    
    
    public List<Persona> getLista() {
        lista = perEJB.findAll();
        return lista;
    }

    public List<Persona> getFilter() {
        return filter;
    }

    public void setFilter(List<Persona> filter) {
        this.filter = filter;
    }

    public void setLista(List<Persona> lista) {
        this.lista = lista;
    }

    public Persona getPer() {
        return per;
    }

    public void setPer(Persona per) {
        this.per = per;
    }

    public Cargo getCar() {
        return car;
    }

    public void setCar(Cargo car) {
        this.car = car;
    }

    public Sucursal getSuc() {
        return suc;
    }

    public void setSuc(Sucursal suc) {
        this.suc = suc;
    }

    @PostConstruct
    public void init() {
        per = new Persona();
        car = new Cargo();
        suc = new Sucursal();

    }

    public void refresh() {
        this.lista = this.perEJB.findAll();
    }

    public void create() {
        FacesMessage message;
        try {
            per.setId_cargo(car);
            per.setId_sucursal(suc);
            perEJB.create(per);
            init();
            refresh();
            message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Exito", "Datos Guardados");
        } catch (Exception e) {
            message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "Error al guardar");
        }
        FacesContext.getCurrentInstance().addMessage(null, message);
    }

    public void update() {
        FacesMessage message;
        try {
            per.setId_cargo(car);
            per.setId_sucursal(suc);
            perEJB.edit(per);
            init();
            refresh();
            message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Exito", "Datos Modificados");
        } catch (Exception e) {
            message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "Error al Modificar");
        }
        FacesContext.getCurrentInstance().addMessage(null, message);
    }

    public void delete(Persona per) {
        FacesMessage message;
        try {
            perEJB.delete(per);
            init();
            refresh();
            message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Exito", "Datos Eliminados");
        } catch (Exception e) {
            message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "Error al Eliminar");
        }
        FacesContext.getCurrentInstance().addMessage(null, message);
    }

    public void find(Persona id) {
        try {
            this.per.setId_cargo(car);
            this.per.setId_sucursal(suc);
            this.per = this.perEJB.find(id.getId_persona());
            perEJB.find(per.getId_persona());
        } catch (Exception e) {
        }
    }

    public boolean globalFilterFunction(
            
            
            
            Object value, Object filter, Locale locale) {
        String filterText = (filter == null) ? null : filter.toString().trim().toLowerCase();
        if (filterText == null || filterText.equals("")) {
            return true;
        }
        int filterInt = getInteger(filterText);

        Persona pers = (Persona) value;
        
        return pers.getNombres().toLowerCase().contains(filterText)
                || pers.getApellidos().toLowerCase().contains(filterText)
                || pers.getDui().toLowerCase().contains(filterText)
                || pers.getGenero().toLowerCase().contains(filterText)
                || pers.getNit().toLowerCase().contains(filterText)
                || pers.getId_cargo().getCargo().toLowerCase().contains(filterText)
                || pers.getId_sucursal().getNombre().toLowerCase().contains(filterText)
                || pers.getId_persona() > filterInt;
    }
    
    private int getInteger(String string) {
        try {
            return Integer.valueOf(string);
        }
        catch (NumberFormatException ex) {
            return 0;
        }
    }

}
