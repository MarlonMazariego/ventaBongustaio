/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import ejb.ComplementoFacadeLocal;
import entity.Complemento;
import entity.TipoComplemento;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

@Named(value = "cComplemento")
@SessionScoped
public class CComplemento implements Serializable {

    @EJB
    private ComplementoFacadeLocal ComplementoEJB;
    private Complemento com;
    private TipoComplemento tipCom;
    private List<Complemento> lista;

    /*Mensaje*/
    private String msj;

    public Complemento getCom() {
        return com;
    }

    public void setCom(Complemento com) {
        this.com = com;
    }

    public TipoComplemento getTipCom() {
        return tipCom;
    }

    public void setTipCom(TipoComplemento tipCom) {
        this.tipCom = tipCom;
    }

    public List<Complemento> getLista() {
        this.lista = ComplementoEJB.findAll();
        return lista;
    }

    public void setLista(List<Complemento> lista) {
        this.lista = lista;
    }

    @PostConstruct
    public void init() {
        com = new Complemento();
        tipCom = new TipoComplemento();
    }

    public void clean() {
        com = new Complemento();
        tipCom = new TipoComplemento();
    }

    public void findAll() {
        try {
            lista = ComplementoEJB.findAll();
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Error " + e.getMessage());
        }
    }

    public void save() {
        FacesMessage mensa;
        try {
            this.com.setId_tipoCom(tipCom);
            this.ComplementoEJB.create(com);
            clean();
            findAll();
            this.msj = "Registro guardado con éxito";
            mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "Operación completada", msj);
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Error" + e.getMessage());
            this.msj = "Ha ocurrido un error mientras se ingresaba el registro";
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Operación Fallida", msj);
        }
        FacesContext.getCurrentInstance().addMessage(msj, mensa);
    }

    public void update() {
        FacesMessage mensa;
        try {
            this.com.setId_tipoCom(tipCom);
            this.ComplementoEJB.create(com);
            clean();
            findAll();
            this.msj = "Registro modificado con éxito";
            mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "Operación completada", msj);
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Error" + e.getMessage());
            this.msj = "Ha ocurrido un error mientras se actualizaba el registro";
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Operación Fallida", msj);
        }
        FacesContext.getCurrentInstance().addMessage(msj, mensa);
    }

    public void delete(Complemento id) {
        FacesMessage mensa;
        try {
            this.ComplementoEJB.delete(id);
            clean();
            findAll();
            this.msj = "Registro eliminado con éxito";
            mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "Operación completada", msj);
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Error" + e.getMessage());
            this.msj = "Ha ocurrido un error mientras se eliminaba el registro";
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Operación Fallida", msj);
        }
        FacesContext.getCurrentInstance().addMessage(msj, mensa);
    }

    public void find(Complemento id) {
        FacesMessage mensa;
        try {
            this.tipCom.setId_tipoCom(id.getId_tipoCom().getId_tipoCom());
            this.com = id;
            this.msj = "Datos cargados con éxito";
            mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "Operación completada", msj);
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Error" + e.getMessage());
            this.msj = "Ha ocurrido un error mientras se cargaba el registro";
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Operación Fallida", msj);
        }
        FacesContext.getCurrentInstance().addMessage(msj, mensa);
    }

}
