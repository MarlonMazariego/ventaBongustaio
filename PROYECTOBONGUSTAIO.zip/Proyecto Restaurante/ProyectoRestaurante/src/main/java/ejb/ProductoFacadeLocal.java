/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import entity.Producto;
import java.util.List;
import javax.ejb.Local;

@Local
public interface ProductoFacadeLocal {
    
 void create (Producto producto);
    
    List<Producto> findAll();
    
    void delete(Producto producto);
    
    void edit(Producto producto);
    
    Producto find(Object id);
    
    /*LISTA BEBIDAS*/
    List<Producto> getBebidas();
    
    /*LISTA COMPLEMENTOS*/
    List<Producto> getComplementos();
}
