/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import entity.Sucursal;
import java.util.List;
import javax.ejb.Local;

@Local
public interface SucursalFacadeLocal {
    
 void create (Sucursal sucursal);
    
    List<Sucursal> findAll();
    
    void delete(Sucursal sucursal);
    
    void edit(Sucursal sucursal);
    
    Sucursal find(Object id);  
}
