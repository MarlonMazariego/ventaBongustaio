/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import entity.TipoSucursal;
import java.util.List;
import javax.ejb.Local;

@Local
public interface TipoSucursalFacadeLocal {

    void create(TipoSucursal encuesta);

    List<TipoSucursal> findAll();

    void edit(TipoSucursal entity);

    void delete(TipoSucursal entity);

    TipoSucursal find(Object id);
}
