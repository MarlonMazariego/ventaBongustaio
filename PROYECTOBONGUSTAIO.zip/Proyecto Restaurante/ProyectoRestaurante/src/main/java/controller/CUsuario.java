/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import ejb.UsuarioFacadeLocal;
import entity.Persona;
import entity.RolesUsuario;
import entity.Usuario;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

@Named(value = "cusuario")
@SessionScoped
public class CUsuario implements Serializable {

    @EJB
    private UsuarioFacadeLocal usuarioEJB;
    private Usuario usu;
    private List<Usuario> lista;
    private Persona per;
    private RolesUsuario rolUsu;


    public Usuario getUsu() {
        return usu;
    }

    public void setUsu(Usuario usu) {
        this.usu = usu;
    }

    public Persona getPer() {
        return per;
    }

    public void setPer(Persona per) {
        this.per = per;
    }

    public RolesUsuario getRolUsu() {
        return rolUsu;
    }

    public void setRolUsu(RolesUsuario rolUsu) {
        this.rolUsu = rolUsu;
    }

    public List<Usuario> getLista() {
        lista = usuarioEJB.findAll();
        return lista;
    }

    public void setLista(List<Usuario> lista) {
        this.lista = lista;
    }

    @PostConstruct
    public void init() {
        usu = new Usuario();
        rolUsu = new RolesUsuario();
        per = new Persona();
    }

    public void save() {
        FacesMessage message;
        try {
            usu.setId_persona(per);
            usu.setId_rolesUsuario(rolUsu);
            usuarioEJB.create(usu);
            init();
            message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Exito", "Datos Guardados");
        } catch (Exception e) {
            message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "Error al guardar");
        }
        FacesContext.getCurrentInstance().addMessage(null, message);
    }

    public void update() {
        FacesMessage message;
        try {
            usu.setId_persona(per);
            usu.setId_rolesUsuario(rolUsu);
            usuarioEJB.edit(usu);
            init();
            message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Exito", "Datos Modificados");
        } catch (Exception e) {
            message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "Error al Modificar");
        }
        FacesContext.getCurrentInstance().addMessage(null, message);
    }

    public void delete(Usuario us) {
        FacesMessage message;
        try {
            usuarioEJB.delete(us);
            init();
            message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Exito", "Datos Eliminados");
        } catch (Exception e) {
            message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "Error al Eliminar");
        }
        FacesContext.getCurrentInstance().addMessage(null, message);
    }

    public void assign(Persona pers) {
        try {
            per = pers;
            usu.setId_persona(pers);
            System.out.println(per.getId_persona());
        } catch (Exception e) {
            FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", e.getMessage());
            FacesContext.getCurrentInstance().addMessage(null, message);
        }
    }

    public void find(Usuario us) {
        try {
            usu = usuarioEJB.find(us.getId_usuario());
            per.setId_persona(usu.getId_persona().getId_persona());
            rolUsu.setId_rolesUsuario(usu.getId_rolesUsuario().getId_rolesUsuario());
            usuarioEJB.find(usu.getId_usuario());
        } catch (Exception e) {
            FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", e.getMessage());
            FacesContext.getCurrentInstance().addMessage(null, message);
        }
    }

    public String login() {
        Usuario usuario;
        String ruta = null;
        try {
            this.usu.setId_rolesUsuario(rolUsu);
            usuario = usuarioEJB.login(usu);
            int rol = usuario.getId_rolesUsuario().getId_rolesUsuario();
            /*OBSERVAR EL ROL*/
            //System.out.println(rol);

            switch (rol) {
                case 1:
                    FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("Usuario", usuario);
                    ruta = "/views/AdminSU/home?faces-redirect=true";
                    break;
                case 2:
                    FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("Usuario", usuario);
                    ruta = "/views/Admin/home?faces-redirect=true";
                    break;
                case 3:
                    FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("Usuario", usuario);
                    ruta = "/views/Users/home?faces-redirect=true";
                    break;
                default:
                    FacesContext.getCurrentInstance().addMessage(
                            null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Aviso", "Revise sus datos e intente nuevamente")
                    );
                    break;
            }

        } catch (Exception e) {
            e.printStackTrace();
            FacesContext.getCurrentInstance().addMessage(
                    null, new FacesMessage(FacesMessage.SEVERITY_FATAL, "Aviso", "No se ha podido iniciar sesión, revise sus datos e intente nuevamente")
            );
        }
        return ruta;
    }

    public String logout() {
        String log = null;
        try {
            System.out.println("hola");
            FacesContext.getCurrentInstance().getExternalContext().invalidateSession();
            FacesContext.getCurrentInstance().getExternalContext().getSessionMap().remove("Usuario");
            log = "/index?faces-redirect=true";
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Error al cerrar sesión");
        }
        return log;
    }

    public void verifySession() {
        Usuario usuario;
        try {
            /*CONVERTIMOS EL SESSION A LA ENTIDAD DE USUARIOS, PONIENDO "(ENTIDAD)" ANTES DEL FacesContext*/
            usuario = (Usuario) FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("Usuario");
            
            if(usuario == null){
                FacesContext.getCurrentInstance().getExternalContext().redirect("../../index.xhtml");
            }
        } catch (Exception e) {
        }
    }

}
