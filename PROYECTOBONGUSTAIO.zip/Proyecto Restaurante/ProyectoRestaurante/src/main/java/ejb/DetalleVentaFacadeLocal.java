/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import entity.DetalleVenta;
import java.util.List;
import javax.ejb.Local;

@Local
public interface DetalleVentaFacadeLocal {
    
     void create(DetalleVenta detalleVenta);
    
    List<DetalleVenta> findAll();
    
    void edit(DetalleVenta detalleVenta);
    
    void delete(DetalleVenta detalleVenta);
    
    DetalleVenta find(Object id);
}
