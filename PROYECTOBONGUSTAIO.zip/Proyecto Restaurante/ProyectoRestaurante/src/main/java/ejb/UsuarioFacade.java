/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import entity.Usuario;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

@Stateless
public class UsuarioFacade extends AbstractFacade<Usuario> implements UsuarioFacadeLocal {

    @PersistenceContext(unitName = "pvb")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public UsuarioFacade() {
        super(Usuario.class);
    }

    /*FUNCIÓN PERSONALIZADA PARA REALIZAR EL INICIO DE SESIÓN Enc:Fer*/
    public Usuario login(Usuario us) {
        Usuario user = null;
        try {
            String sql = "SELECT u from Usuario u where u.nickName = ?1 and u.pass = ?2";

            Query q = em.createQuery(sql);
            q.setParameter(1, us.getNickName());
            q.setParameter(2, us.getPass());

            List<Usuario> reg = q.getResultList();

            if (!reg.isEmpty()) {
                user = reg.get(0);
            } else {
                System.out.println("Lista fallida");
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Error al loguear " + e.getMessage());
        }
        return user;
    }

}
