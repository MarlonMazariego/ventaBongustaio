/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import ejb.TiempoFacadeLocal;
import entity.Tiempo;
import entity.TipoSucursal;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

/**
 *
 * @author claudia.pinedausam
 */
@Named(value = "cTiempo")
@SessionScoped
public class CTiempo implements Serializable {

    @EJB
    private TiempoFacadeLocal tieEJB;
    private Tiempo tiempo;
    private List<Tiempo> lista;
    private String msj;
    private TipoSucursal tipoSucursal;

    public Tiempo getTiempo() {
        return tiempo;
    }

    public void setTiempo(Tiempo tiempo) {
        this.tiempo = tiempo;
    }

    public List<Tiempo> getLista() {
        lista = tieEJB.findAll();
        return lista;
    }

    public void setLista(List<Tiempo> lista) {
        this.lista = lista;
    }

    public TipoSucursal getTipoSucursal() {
        return tipoSucursal;
    }

    public void setTipoSucursal(TipoSucursal tipoSucursal) {
        this.tipoSucursal = tipoSucursal;
    }

    @PostConstruct
    public void init() {
        this.tiempo = new Tiempo();
        lista = tieEJB.findAll();
        tipoSucursal = new TipoSucursal();
    }

    public void create() {
        FacesMessage mensa;
        try {
            tiempo.setId_tipoSucursal(tipoSucursal);
            tieEJB.create(tiempo);
            msj = "Datos guardados correctamente";
            mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "Completado", msj);
            tipoSucursal = new TipoSucursal();
            init();
        } catch (Exception e) {
            msj = "Error al guardar los datos";
            System.out.println("ERROR" + e.getMessage());
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", msj);
        }
        FacesContext.getCurrentInstance().addMessage(msj, mensa);
    }

    public void controlAll() {
        try {
            lista = tieEJB.findAll();
        } catch (Exception e) {
        }
    }

    public void delete(Tiempo tp) {
        FacesMessage mensa;
        try {
            tieEJB.delete(tp);
            msj = "Datos eliminados correctamente";
            mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "Completado", msj);
        } catch (Exception e) {
            msj = "Error al guardar los datos";
            System.out.println("Error" + e.getMessage());
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", msj);
        }
        FacesContext.getCurrentInstance().addMessage(msj, mensa);
    }

    public void update() {
        FacesMessage mensa;
        try {
            tiempo.setId_tipoSucursal(tipoSucursal);
            tieEJB.edit(tiempo);
            msj = "Datos actualizados";
            mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "Completado", msj);
        } catch (Exception e) {
            msj = "Error al actualizar datos";
            System.out.println("Error" + e.getMessage());
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", msj);
        }
        FacesContext.getCurrentInstance().addMessage(msj, mensa);
    }

    public void find(Tiempo tp) {
        FacesMessage mensa;
        try {
            this.tipoSucursal.setId_tipoSucursal(tp.getId_tipoSucursal().getId_tipoSucursal());
            this.tiempo = tp;
            this.msj = "Registro cargado correctamente";
            mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "Completado", msj);
        } catch (Exception e) {
            e.printStackTrace();
            this.msj = "No se pudo cargar la información...";
            System.err.println("Error al cargar registro : " + e.getMessage());
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Ups", msj);
        }
        FacesContext.getCurrentInstance().addMessage(msj, mensa);
    }
}
