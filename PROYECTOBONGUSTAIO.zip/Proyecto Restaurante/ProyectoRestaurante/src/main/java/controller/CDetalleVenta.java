/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import ejb.DetalleVentaFacadeLocal;
import entity.Bebida;
import entity.Complemento;
import entity.DetalleVenta;
import entity.Platillo;
import entity.Venta;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

/*
 *  Pc
 *  fernando.barrazausam
 *
 */
@Named(value = "cDetalleVenta")
@SessionScoped
public class CDetalleVenta implements Serializable {

    @EJB
    private DetalleVentaFacadeLocal detVenEJB;
    private DetalleVenta detVen;
    private List<DetalleVenta> lista;

    /*FORANEAS*/
    private Venta ven;
    private Platillo pla;
    private Bebida beb;
    private Complemento com;

    /*MENSAJE*/
    private String msj;

    public DetalleVentaFacadeLocal getDetVenEJB() {
        return detVenEJB;
    }

    public void setDetVenEJB(DetalleVentaFacadeLocal detVenEJB) {
        this.detVenEJB = detVenEJB;
    }

    public DetalleVenta getDetVen() {
        return detVen;
    }

    public void setDetVen(DetalleVenta detVen) {
        this.detVen = detVen;
    }

    public Venta getVen() {
        return ven;
    }

    public void setVen(Venta ven) {
        this.ven = ven;
    }

    public Platillo getPla() {
        return pla;
    }

    public void setPla(Platillo pla) {
        this.pla = pla;
    }

    public Bebida getBeb() {
        return beb;
    }

    public void setBeb(Bebida beb) {
        this.beb = beb;
    }

    public Complemento getCom() {
        return com;
    }

    public void setCom(Complemento com) {
        this.com = com;
    }

    public List<DetalleVenta> getLista() {
        this.lista = detVenEJB.findAll();
        return lista;
    }

    public void setLista(List<DetalleVenta> lista) {
        this.lista = lista;
    }

    @PostConstruct
    public void init() {
        ven = new Venta();
        pla = new Platillo();
        beb = new Bebida();
        com = new Complemento();
        detVen = new DetalleVenta();

    }

    public void clear() {
        ven = new Venta();
        pla = new Platillo();
        beb = new Bebida();
        com = new Complemento();
        detVen = new DetalleVenta();
    }

    public void findAll() {
        try {
            this.lista = detVenEJB.findAll();
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Error al actualizar " + e.getMessage());
        }
    }

    public void save() {
        FacesMessage mensa;
        try {
            detVen.setId_venta(ven);
            detVen.setId_platillo(pla);
            detVen.setId_bebida(beb);
            detVen.setId_complemento(com);
            detVenEJB.create(detVen);
            clear();
            findAll();
            this.msj = "Registro guardado correctamente";
            mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "Operación exitosa", msj);
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Error " + e.getMessage());
            this.msj = "Ha habido un error al ingresar los datos";
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Algo falló...", msj);
        }
        FacesContext.getCurrentInstance().addMessage(msj, mensa);
    }

    public void update() {
        FacesMessage mensa;
        try {
            detVen.setId_venta(ven);
            detVen.setId_platillo(pla);
            detVen.setId_bebida(beb);
            detVen.setId_complemento(com);
            detVenEJB.create(detVen);
            clear();
            findAll();
            this.msj = "Registro guardado correctamente";
            mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "Operación exitosa", msj);
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Error " + e.getMessage());
            this.msj = "Ha habido un error al ingresar los datos";
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Algo falló...", msj);
        }
        FacesContext.getCurrentInstance().addMessage(msj, mensa);
    }

    public void delete(DetalleVenta id) {
        FacesMessage mensa;
        try {
            detVenEJB.delete(id);
            clear();
            findAll();
            this.msj = "Registro guardado correctamente";
            mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "Operación exitosa", msj);
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Error " + e.getMessage());
            this.msj = "Ha habido un error al ingresar los datos";
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Algo falló...", msj);
        }
        FacesContext.getCurrentInstance().addMessage(msj, mensa);
        detVenEJB.delete(id);
    }

    public void find(DetalleVenta id) {
        try {
            this.ven.setId_venta(id.getId_venta().getId_venta());
            this.pla.setId_platillo(id.getId_platillo().getId_platillo());
            this.beb.setId_bebida(id.getId_bebida().getId_bebida());
            this.com.setId_complemento(id.getId_complemento().getId_complemento());
            this.detVen = id;
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Error " + e.getMessage());
        }

    }

}
