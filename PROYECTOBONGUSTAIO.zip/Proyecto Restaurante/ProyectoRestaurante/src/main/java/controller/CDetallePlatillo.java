/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import entity.DetallePlatillo;
import entity.Platillo;
import entity.Producto;
import ejb.DetallePlatilloFacadeLocal;
import java.io.Serializable;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

@Named(value = "cDetallePlatillo")
@SessionScoped
public class CDetallePlatillo implements Serializable {

    @EJB
    private DetallePlatilloFacadeLocal detplaEJB;
    private DetallePlatillo detPla;
    private List<DetallePlatillo> lista;
    private String msj = "";

    /*FORANEAS*/
    private Platillo pla;
    private Producto pro;

    public DetallePlatillo getDetPla() {
        return detPla;
    }

    public void setDetPla(DetallePlatillo detPla) {
        this.detPla = detPla;
    }

    public List<DetallePlatillo> getLista() {
        return lista;
    }

    public void setLista(List<DetallePlatillo> lista) {
        this.lista = lista;
    }

    public Platillo getPla() {
        return pla;
    }

    public void setPla(Platillo pla) {
        this.pla = pla;
    }

    public Producto getPro() {
        return pro;
    }

    public void setPro(Producto pro) {
        this.pro = pro;
    }

    @PostConstruct
    public void init() {
        this.detPla = new DetallePlatillo();
        lista = detplaEJB.findAll();
        pla = new Platillo();
        pro = new Producto();
    }

    public void create() {
        FacesMessage mensa;
        try {
            detPla.setId_producto(pro);
            detPla.setId_platillo(pla);
            detplaEJB.create(detPla);
            msj = "Datos actualizados correcatemente";
            mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "Completado", msj);
            pla = new Platillo();
            pro = new Producto();
        } catch (Exception e) {
            msj = "Error al guardar los datos";
            System.out.println("Error" + e.getMessage());
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", msj);
        }
        FacesContext.getCurrentInstance().addMessage(null, mensa);
    }

    public void controlAll() {
        try {
            lista = detplaEJB.findAll();
        } catch (Exception e) {
        }
    }

    public void delete(DetallePlatillo dp) {
        FacesMessage mensa;
        try {
            detplaEJB.delete(dp);
            msj = "Datos eliminados correctamente";
            mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "Completado", msj);
        } catch (Exception e) {
            msj = "Error al Eliminar los datos";
            System.out.println("Error" + e.getMessage());
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", msj);
        }
        FacesContext.getCurrentInstance().addMessage(null, mensa);
    }

    public void update() {
        FacesMessage mensa = null;
        try {
            detPla.setId_producto(pro);
            detPla.setId_platillo(pla);
            detplaEJB.edit(detPla);
            msj = "Datos actualizados";
        } catch (Exception e) {
            msj = "Error al Actualizar los datos";
            System.out.println("Error" + e.getMessage());
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", msj);
        }
        FacesContext.getCurrentInstance().addMessage(null, mensa);
    }

    public void find(DetallePlatillo dp) {
        try {
            this.pla.setId_platillo(dp.getId_platillo().getId_platillo());
            this.pro.setId_producto(dp.getId_producto().getId_producto());
            this.detPla = dp;
        } catch (Exception e) {
            System.out.println("Error" + e.getMessage());
        }
    }

}
