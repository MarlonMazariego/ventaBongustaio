/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import ejb.VentaFacadeLocal;
import entity.Bebida;
import entity.Complemento;
import entity.Platillo;
import entity.Usuario;
import entity.Venta;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.List;
import javafx.scene.control.TreeTableColumn.CellEditEvent;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

/**
 *
 * @author Fernando
 */
@Named(value = "cVenta")
@SessionScoped
public class CVenta implements Serializable {

    @EJB
    private VentaFacadeLocal ventasEJB;

    private List<Venta> lista;
    private Venta ven;

    /*FORANEA*/
    private Usuario usu;

    /*RECOJE LISTADO DE PLATILLOS*/
    private String[] platillos;
    private String[] bebidas;
    private String[] complementos;
    private String[] cantP;
    private String msj;

    /*LISTAS DE PLATILLOS, BEBIDAS Y COMPLEMENTOS PEDIDOS*/
    private List listaPlatillo;
    private List listaBebida;
    private List listaComplemento;
    
    private Platillo pla;
    private Bebida beb;
    private Complemento com;

    /*GET Y SET*/
    public String[] getPlatillos() {
        return platillos;
    }

    public void setPlatillos(String[] platillos) {
        this.platillos = platillos;
    }

    public String[] getBebidas() {
        return bebidas;
    }

    public void setBebidas(String[] bebidas) {
        this.bebidas = bebidas;
    }

    public String[] getComplementos() {
        return complementos;
    }

    public void setComplementos(String[] complementos) {
        this.complementos = complementos;
    }

    public List<Venta> getLista() {
        return lista;
    }

    public void setLista(List<Venta> lista) {
        this.lista = lista;
    }

    public Venta getVen() {
        return ven;
    }

    public void setVen(Venta ven) {
        this.ven = ven;
    }

    public Usuario getUsu() {
        return usu;
    }

    public void setUsu(Usuario usu) {
        this.usu = usu;
    }

   
    public Platillo getPla() {
        return pla;
    }

    public void setPla(Platillo pla) {
        this.pla = pla;
    }

    public Bebida getBeb() {
        return beb;
    }

    public void setBeb(Bebida beb) {
        this.beb = beb;
    }

    public Complemento getCom() {
        return com;
    }

    public void setCom(Complemento com) {
        this.com = com;
    }

    public List getListaPlatillo() {
        return listaPlatillo;
    }

    public void setListaPlatillo(List listaPlatillo) {
        this.listaPlatillo = listaPlatillo;
    }

    public List getListaBebida() {
        return listaBebida;
    }

    public void setListaBebida(List listaBebida) {
        this.listaBebida = listaBebida;
    }

    public List getListaComplemento() {
        return listaComplemento;
    }

    public void setListaComplemento(List listaComplemento) {
        this.listaComplemento = listaComplemento;
    }

    public String[] getCantP() {
        return cantP;
    }

    public void setCantP(String[] cantP) {
        this.cantP = cantP;
    }
    
    
    

    @PostConstruct
    public void init() {
        this.ven = new Venta();
        this.usu = new Usuario();
        this.listaPlatillo = null;
        this.listaBebida = null;
        this.listaComplemento = null;
        this.pla = new Platillo();
        this.beb = new Bebida();
        this.com = new Complemento();
    }


    /*HISTORICO DE VENTAS SUPER USUARIO*/
    public void findAll() {
        try {
            this.lista = this.ventasEJB.findAll();
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Error al mostrar lista : " + e.getMessage());
        }
    }

    public void save() {
        FacesMessage mensa;
        try {
            this.usu = (Usuario) FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("Usuario");
            this.ven.setId_usuario(usu);
            this.ventasEJB.create(ven);
            this.msj = "Registro guardado con éxito";
            mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "Informe", msj);

        } catch (Exception e) {
            e.printStackTrace();
            this.msj = "Algo ha fallado...";
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Informe", msj + " " + e.getMessage());
        }

        FacesContext.getCurrentInstance().addMessage(msj, mensa);
    }

    public void update() {
        FacesMessage mensa;
        try {
            this.ven.setId_usuario(usu);//Foranea
            this.ventasEJB.edit(ven);
            this.msj = "Registro modificado con éxito";
            mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "Informe", msj);
        } catch (Exception e) {
            e.printStackTrace();
            this.msj = "Algo ha fallado...";
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Informe", msj + " " + e.getMessage());
        }

        FacesContext.getCurrentInstance().addMessage(msj, mensa);
    }

    public void find(Venta vn) {
        FacesMessage mensa = null;
        try {
            this.usu.setId_usuario(vn.getId_usuario().getId_usuario());
            this.ven = vn;
        } catch (Exception e) {
            e.printStackTrace();
            this.msj = "Algo ha fallado...";
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Informe", msj + " " + e.getMessage());
        }
        FacesContext.getCurrentInstance().addMessage(msj, mensa);
    }

    public void delete(Venta vn) {
        FacesMessage mensa;
        try {
            this.ventasEJB.delete(vn);
            this.msj = "Registro eliminado con éxito";
            mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "Informe", msj);
        } catch (Exception e) {
            e.printStackTrace();
            this.msj = "Algo ha fallado...";
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Informe", msj + " " + e.getMessage());
        }
        FacesContext.getCurrentInstance().addMessage(msj, mensa);
    }

    public void upPlatillos() {
        FacesMessage mensa = null;
        try {
            if (platillos.length > 0) {
                for (int i = 0; i < platillos.length; i++) {
                    this.pla.setId_platillo(Integer.parseInt(platillos[i]));
                    System.out.println(pla.getNombrePlatillo());
                    this.listaPlatillo.add(pla);

                    this.pla = new Platillo();
                }
                this.msj = "Platillos seleccionados";
                mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "Informe", msj);
            } else {
                this.msj = "Seleccione al menos un platillo...";
            }
        } catch (Exception e) {
            e.printStackTrace();
            this.msj = "Algo ha fallado...";
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Informe", msj + " " + e.getMessage());
        }
        FacesContext.getCurrentInstance().addMessage(msj, mensa);
    }


   

}
